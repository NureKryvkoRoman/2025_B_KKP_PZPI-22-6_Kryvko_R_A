package ua.nure.kryvko.greenmonitor.notification;

public enum NotificationUrgency {
    INFO,
    WARNING,
    CRITICAL
}
