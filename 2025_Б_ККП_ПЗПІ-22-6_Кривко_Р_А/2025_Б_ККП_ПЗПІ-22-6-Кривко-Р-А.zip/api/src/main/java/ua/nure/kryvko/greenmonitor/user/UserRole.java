package ua.nure.kryvko.greenmonitor.user;

public enum UserRole {
    ADMIN,
    USER
}
