package ua.nure.kryvko.greenmonitor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreenmonitorApplication {

	public static void main(String[] args) {
		SpringApplication.run(GreenmonitorApplication.class, args);
	}

}
