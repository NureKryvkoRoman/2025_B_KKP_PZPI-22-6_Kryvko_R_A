package ua.nure.kryvko.greenmonitor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreenmonitorApplicationTests {

	@Test
	void contextLoads() {
	}

}
